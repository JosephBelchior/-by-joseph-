By submitting a pull request, you represent that you have the right to license
your contribution to the community, and agree by submitting the patch
that your contributions are licensed under the Apache 2.0 license (see
`LICENSE.txt`).

